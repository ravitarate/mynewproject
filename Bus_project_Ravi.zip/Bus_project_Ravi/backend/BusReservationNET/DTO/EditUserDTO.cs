﻿namespace BusReservationNET.DTO
{
    public class EditUserDTO
    {
        public string Username { get; set; }
        public string Contact { get; set; }
        public string Email { get; set; }
        public string Address { get; set; }
    }
}
