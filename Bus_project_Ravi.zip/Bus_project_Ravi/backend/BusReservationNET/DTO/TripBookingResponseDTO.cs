﻿namespace BusReservationNET.DTO
{
    public class TripBookingResponseDTO
    {

        public string PassengerName { get; set; }
        public string SeatNumber { get; set; }
        public string Phone { get; set; }
    }
}
